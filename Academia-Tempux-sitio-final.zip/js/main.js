/* Academia Tempux · comportamiento del sitio (JavaScript puro, sin dependencias) */
(function () {
  'use strict';

  var WA = '573182652966';
  var VIEWS = ['inicio', 'conocenos', 'tecnicos', 'cursos', 'contacto', 'legal'];
  var $ = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };

  /* ---------- Títulos de subpágina: ocupan todo el ancho, proporcionalmente ---------- */
  function fitTitles() {
    var wide = window.innerWidth >= 760;
    $$('.view:not([hidden]) h1.fith').forEach(function (h) {
      if (!wide) { h.style.fontSize = ''; return; }
      h.style.fontSize = '100px';
      var lines = $$('.fitline', h), max = 0;
      lines.forEach(function (l) { l.style.width = 'max-content'; max = Math.max(max, l.getBoundingClientRect().width); });
      lines.forEach(function (l) { l.style.width = ''; });
      var W = h.clientWidth;
      if (max > 0 && W > 0) h.style.fontSize = (Math.floor(100 * W / max * 0.99 * 10) / 10) + 'px';
    });
  }
  window.addEventListener('resize', fitTitles);
  window.addEventListener('load', fitTitles);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitTitles);

  /* ---------- Navegación entre subpáginas ---------- */
  function current() {
    var h = (location.hash || '').replace('#', '');
    if (h.indexOf('legal-') === 0) h = 'legal';
    return VIEWS.indexOf(h) > -1 ? h : 'inicio';
  }

  function show(view, opts) {
    opts = opts || {};
    if (VIEWS.indexOf(view) < 0) view = 'inicio';
    $$('.view').forEach(function (el) { el.hidden = el.getAttribute('data-view') !== view; });
    $$('a.nl').forEach(function (a) {
      a.classList.toggle('on', a.getAttribute('href') === '#' + view);
    });
    var title = { inicio: 'Academia Tempux · Academia de Belleza y Artes · Cúcuta', conocenos: 'Conócenos · Academia Tempux', tecnicos: 'Técnicos · Academia Tempux', cursos: 'Cursos cortos · Academia Tempux', contacto: 'Contáctanos · Academia Tempux', legal: 'Información legal · Academia Tempux' };
    document.title = title[view];
    fitTitles();
    if (typeof setMenu === 'function') setMenu(false);
    var hh = (location.hash || '').replace('#', '');
    if (view === 'legal' && hh.indexOf('legal-') === 0 && document.getElementById(hh)) {
      setTimeout(function () { document.getElementById(hh).scrollIntoView({ behavior: opts.instant ? 'auto' : 'smooth', block: 'start' }); }, 40);
      return;
    }
    if (!opts.keepScroll) window.scrollTo({ top: 0, behavior: opts.instant ? 'auto' : 'smooth' });
  }

  function go(view, instant) {
    if (current() !== view) {
      history.pushState(null, '', '#' + view);
    }
    show(view, { instant: instant });
  }

  window.addEventListener('popstate', function () { show(current(), { instant: true }); });
  window.addEventListener('hashchange', function () { show(current(), { instant: true }); });

  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a[href^="#"]') : null;
    if (!a) return;
    if (a.hasAttribute('data-ver')) return; // lo maneja el efecto de vidrio de la galería
    var name = a.getAttribute('href').slice(1);
    if (name.indexOf('legal-') === 0) {
      e.preventDefault();
      if (location.hash !== '#' + name) history.pushState(null, '', '#' + name);
      show('legal', {});
    } else if (VIEWS.indexOf(name) > -1) {
      e.preventDefault();
      go(name);
    } else {
      e.preventDefault(); // enlaces pendientes (#, redes sociales sin completar)
    }
  });

  /* ---------- Menú hamburguesa (móvil y tablet) ---------- */
  var bar = $('header.bar');
  var burger = $('.burger');
  function setMenu(open) {
    if (!bar || !burger) return;
    bar.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    burger.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
  }
  if (burger) burger.addEventListener('click', function () { setMenu(!bar.classList.contains('open')); });
  document.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('header.bar nav a')) setMenu(false);
    else if (bar && bar.classList.contains('open') && !(e.target.closest && e.target.closest('header.bar'))) setMenu(false);
  });
  window.addEventListener('resize', function () { if (window.innerWidth > 940) setMenu(false); });

  /* ---------- Efecto vidrio que sigue al cursor ---------- */
  document.addEventListener('mousemove', function (e) {
    var el = e.target.closest ? e.target.closest('[data-track]') : null;
    if (!el) return;
    var r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    el.style.setProperty('--mx', ((e.clientX - r.left) / r.width * 100) + '%');
    el.style.setProperty('--my', ((e.clientY - r.top) / r.height * 100) + '%');
  });

  /* ---------- Acordeones (temario y cursos) ---------- */
  function setAccordion(article, open) {
    var grid = $('div[style*="grid-template-rows"]', article);
    if (!grid) return;
    var inner = grid.firstElementChild;
    var btn = $('[data-toggle]', article);
    grid.style.gridTemplateRows = open ? '1fr' : '0fr';
    inner.style.visibility = open ? 'visible' : 'hidden';
    inner.style.transition = 'visibility 0s linear ' + (open ? '0s' : '.55s');
    if (btn) {
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      var chev = $('svg[style*="rotate"]', btn);
      if (chev) chev.style.transform = 'rotate(' + (open ? '180deg' : '0deg') + ')';
      var label = $('span', btn);
      if (label) {
        var tech = btn.getAttribute('data-toggle') === 'tech';
        label.textContent = open ? (tech ? 'Cerrar temario' : 'Cerrar cursos') : (tech ? 'Más info' : 'Cursos');
      }
    }
    article.setAttribute('data-open', open ? 'true' : 'false');
  }

  document.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('[data-toggle]') : null;
    if (!btn) return;
    var article = btn.closest('article');
    var group = btn.getAttribute('data-toggle');
    var willOpen = article.getAttribute('data-open') !== 'true';
    $$('article[data-open="true"]').forEach(function (other) {
      var ob = $('[data-toggle]', other);
      if (other !== article && ob && ob.getAttribute('data-toggle') === group) setAccordion(other, false);
    });
    setAccordion(article, willOpen);
  });

  /* ---------- Buzón → WhatsApp ---------- */
  var tipo = 'Sugerencia';
  function updateBuzon() {
    var nombre = ($('#bz-nombre') || {}).value || '';
    var mensaje = ($('#bz-mensaje') || {}).value || '';
    var txt = 'Buzón Academia Tempux\nTipo: ' + tipo + '\nNombre: ' + (nombre || '(sin nombre)') + '\nMensaje: ' + mensaje;
    var link = $('#bz-wa');
    if (link) link.href = 'https://wa.me/' + WA + '?text=' + encodeURIComponent(txt);
  }
  document.addEventListener('click', function (e) {
    var chip = e.target.closest ? e.target.closest('[data-tipo]') : null;
    if (!chip) return;
    tipo = chip.getAttribute('data-tipo');
    $$('[data-tipo]').forEach(function (c) { c.classList.toggle('on', c === chip); });
    updateBuzon();
  });
  document.addEventListener('input', function (e) {
    if (e.target.id === 'bz-nombre' || e.target.id === 'bz-mensaje') updateBuzon();
  });
  updateBuzon();

  /* ---------- Galería → técnico, con transición de vidrio ---------- */
  function openTecnico(id) {
    show('tecnicos', { instant: true, keepScroll: true });
    history.pushState(null, '', '#tecnicos');
    window.scrollTo({ top: 0 });
    $$('article[data-open="true"]').forEach(function (a) { setAccordion(a, false); });
    var card = document.getElementById('t-' + id);
    if (card) {
      setAccordion(card, true);
      setTimeout(function () { card.scrollIntoView({ block: 'center' }); }, 60);
    }
  }

  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-ver]') : null;
    if (!b) return;
    e.preventDefault();
    var id = b.getAttribute('data-ver');
    var x = e.clientX || window.innerWidth / 2, y = e.clientY || window.innerHeight / 2;
    var cv = document.createElement('div');
    cv.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:200;pointer-events:none;background:radial-gradient(circle at ' + x + 'px ' + y + 'px,rgba(212,38,47,.5),rgba(10,10,11,.86));-webkit-backdrop-filter:blur(26px);backdrop-filter:blur(26px)';
    document.body.appendChild(cv);
    var r = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y)) + 20;
    if (!cv.animate) { openTecnico(id); cv.remove(); return; }
    var inn = cv.animate([{ clipPath: 'circle(0px at ' + x + 'px ' + y + 'px)' }, { clipPath: 'circle(' + r + 'px at ' + x + 'px ' + y + 'px)' }], { duration: 560, easing: 'cubic-bezier(.7,0,.2,1)', fill: 'forwards' });
    inn.onfinish = function () {
      openTecnico(id);
      setTimeout(function () {
        cv.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 650, easing: 'ease', fill: 'forwards' }).onfinish = function () { cv.remove(); };
      }, 150);
    };
  });

  /* ---------- Galería del inicio: pausar si se prefiere menos movimiento ---------- */
  /* (el CSS ya lo maneja con prefers-reduced-motion) */

  /* ---------- Carrusel de graduaciones (inicio) ---------- */
  (function () {
    var root = $('.hcar'); if (!root) return;
    var slides = $$('.hcar-slide', root), dots = $$('.hcar-dots button', root), i = 0, timer = null;
    function go(n) {
      i = (n + slides.length) % slides.length;
      slides.forEach(function (s, k) { s.classList.toggle('on', k === i); s.setAttribute('aria-hidden', k === i ? 'false' : 'true'); });
      dots.forEach(function (d, k) { d.classList.toggle('on', k === i); d.setAttribute('aria-current', k === i ? 'true' : 'false'); });
    }
    function stop() { clearInterval(timer); timer = null; }
    function start() {
      stop();
      timer = setInterval(function () { go(i + 1); }, 5500);
    }
    $('.hcar-btn.prev', root).addEventListener('click', function () { go(i - 1); start(); });
    $('.hcar-btn.next', root).addEventListener('click', function () { go(i + 1); start(); });
    dots.forEach(function (d, k) { d.addEventListener('click', function () { go(k); start(); }); });
    var x0 = null;
    root.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
    root.addEventListener('touchend', function (e) { if (x0 === null) return; var dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 40) { go(i + (dx < 0 ? 1 : -1)); start(); } x0 = null; }, { passive: true });
    go(0); start();
  })();

  /* ---------- Arranque ---------- */
  show(current(), { instant: true, keepScroll: true });
})();
